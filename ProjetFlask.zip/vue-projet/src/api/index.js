import axios from 'axios';
import json from '../json/config.json';
export function authenticate(user) {
    var res = axios.post('http://'+json.ip+':'+json.port+'/login', user)
    return res
}
  
export function register(user) {
    var res =  axios.post('http://'+json.ip+':'+json.port+'/account', user)
    console.log(res.data)
    return res
   
}