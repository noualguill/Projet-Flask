

<template>
<html >

<body>
  <main>
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6 login-section-wrapper">

          <div class="login-wrapper my-auto">
            <h1 class="login-title">Se connecter</h1>
            <form action="#!">
                        <div class="text-center">
                            <div>
                                <label class="widget-heading">Username:</label>
                                <div class="control">
                                    <input type="txt" class="input is-large" id="user" v-model="user">
                                </div>
                            </div>
                            <div class="field">
                                <label class="widget-heading">Password:</label>
                                <div class="control">
                                    <input type="password" class="input is-large" id="pwd" v-model="pwd">
                                </div>
                            </div>
                        </div>
              <p v-if="errorMessage!=null">{{ errorMessage }}</p>
                            <div class="control">
                                <a class="btn btn-info" @click="authenticate">Connexion</a>
                            </div>
            </form>
   
            <p class="login-wrapper-footer-text">Besoin de créer un compte?  <router-link class="btn btn-txt" to="/Signup">S'inscrire</router-link></p>
          </div>
        </div>

      </div>
    </div>
  </main>
 
</body>
</html>
</template>

<script>
    import { EventBus } from '@/utils'
    import md5 from 'js-md5'
    export default {
        data() {
            return {
                user: '',
                pwd: '',
                errorMessage: ''
            }
        },
        methods: {
            authenticate () {
               
           
           
                this.$store.dispatch('login', { user: this.user, pwd: md5(this.pwd) })
                    .then(() => this.$router.push('/'))
            },
        },
        mounted () {
            EventBus.$on('failedAuthentication', (message) => {
                this.errorMessage = message
            })
        },
        beforeDestroy () {
            EventBus.$off('failedAuthentication')
        }
    };
</script>

<style>
.scroll-area-sm-dis {
    height: 12em;
    overflow-x: hidden
}
</style>