<template>
<html >

<body>
  <main>
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6 login-section-wrapper">

          <div class="login-wrapper my-auto">
            <h1 class="login-title">S'inscrire</h1>
            <form action="#!">
                        <div class="text-center">
                            <div>
                                <label class="widget-heading">Username:</label>
                                <div class="control">
                                    <input type="txt" class="input is-large" id="user" v-model="user">
                                </div>
                            </div>
                            <div class="field">
                                <label class="widget-heading">Password:</label>
                                <div class="control">
                                    <input type="password" class="input is-large" id="pwd" v-model="pwd">
                                </div>
                            </div>
                        </div>                            
              <p v-if="errorMessage!=null">{{ errorMessage }}</p>
                             <div class="control">
                                <a class="btn btn-info" @click="register">Inscription</a>
                            </div>
            </form>
   
            <p class="login-wrapper-footer-text">Déjà un compte?  <router-link class="btn btn-txt" to="/Login">Se connecter</router-link></p>
          </div>
        </div>

      </div>
    </div>
  </main>
 
</body>
</html>

</template>

<script>
    import { EventBus } from '@/utils'
    import md5 from 'js-md5'
    
    export default {
        data() {
            return {
                user: '',
                pwd: '',
                errorMessage: ''
            }
        },
        methods: {
            register () {
                
                this.$store.dispatch('register', { user: this.user, pwd: md5(this.user) })
                    .then(() => this.$router.push('/'))
            }
        },
        mounted () {
            EventBus.$on('failedRegistering', (message) => {
                this.errorMessage = message
            })
        },
        beforeDestroy () {
            EventBus.$off('failedRegistering')
        }
    };
</script>