import Vue from 'vue'

export const EventBus = new Vue()

export function isValidJwt (jwt) {
  console.log(jwt)
  return(jwt)


}