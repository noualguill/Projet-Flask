from app import app
from app import config
if __name__ == "__main__":
    app.run(port="5001",host="127.0.0.1")