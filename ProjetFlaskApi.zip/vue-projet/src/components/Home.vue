<template>
    <div class="row d-flex justify-content-center">
        <div class="col-md-10 mt-4">
            <div class="card-hover-shadow-2x mb-3 card">
                <div class="card-header-tab card-header">
                <button @click="logout">Déconnexion</button>
                    <div class="card-header-title font-size-lg text-capitalize font-weight-normal">{{$store.getters.getUserData.username}}</div>
                </div>
                <div class="scroll-area-sm">
                    <div style="position: static;" class="ps ps--active-y">
                        <div class="ps-content">
                            <ul class=" list-group list-group-flush" v-for="todo in todolists" v-bind:key="todo.id_list">
                                <li class="list-group-item">
                                    <div class="todo-indicator bg-gradient"></div>
                                    <div class="widget-content p-0 ml-4">
                                        <div class="widget-content-wrapper">
                                            <div class="widget-content-left">
                                                <div class="widget-heading">{{ todo[0]['name'] }}
                                                </div>
                                               
                                            </div>
                                            <div class="widget-content-right">
                                                <router-link class="border-0 btn-transition btn btn-outline-info" :to="{path : '/Tasks/' + todo[0]['id_list']}">Voir contenu</router-link>
                                                <button class="border-0 btn-transition btn btn-outline-warning" v-b-modal.edit-list-modal v-on:click="editListId(todo[0]['id_list'])">Edit</button>
                                                <button class="border-0 btn-transition btn btn-outline-danger" v-on:click="deleteList(todo[0]['id_list'])">Delete</button>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="d-block text-center card-footer">
                    <button class="btn btn-txt" v-b-modal.add-list-modal><font-awesome-icon class="font" icon="plus"/> &nbsp;Add List</button>
                </div>
            </div>
        </div>
        <b-modal ref="addListModal"
                id="add-list-modal"
                title="Add a new list"
                hide-footer>
            <b-form @submit="onSubmitAddList" @reset="onResetAddList" class="w-100">
                <b-form-group id="form-title-add-group"
                            label="Title:"
                            label-for="form-title-add-input">
                    <b-form-input id="form-title-add-input"
                                type="text"
                                v-model="addListForm.name"
                                required
                                placeholder="Enter title">
                    </b-form-input>
                </b-form-group>
                <b-button pill type="submit" variant="info" class="ml-4 mr-4">Submit</b-button>
                <b-button pill type="reset" variant="danger" class="ml-4">Reset</b-button>
            </b-form>
        </b-modal>
        <b-modal ref="editListModal"
                id="edit-list-modal"
                title="Edit a list"
                hide-footer>
            <b-form @submit="onSubmitEditList" @reset="onResetEditList" class="w-100">
                <b-form-group id="form-title-edit-group"
                            label="Title:"
                            label-for="form-title-edit-input">
                    <b-form-input id="form-title-edit-input"
                                type="text"
                                v-model="editListForm.name"
                                required
                                placeholder="Enter title">
                    </b-form-input>
                </b-form-group>
                <b-button pill type="submit" variant="info" class="ml-4 mr-4">Submit</b-button>
                <b-button pill type="reset" variant="danger" class="ml-4">Reset</b-button>
            </b-form>
        </b-modal>
    </div>
</template>

<script>
    import axios from 'axios';
    import json from '../json/config.json';
    export default {
        data() {
    
            return {
                todolists: [],
                addListForm: {
                    name: '',
                    id_list:''
                 
                },
                editListForm: {
                    id_list: '',
                    name: '',
                    content:''
                },
            };
        },
        methods: {
            getTodolists() {
                const path = 'http://'+json.ip+':'+json.port+'/lists';
                const token = this.$store.getters.getJwtToken;
                axios.get(path, {headers: {token: token}})
                    .then((res) => {               
                        this.todolists = res.data.data;
                       
                        
                    })
                    .catch((error) => {
                        console.error(error);
                    });
                
            },
            logout(){
                document.location.reload();
            },
            addList(payload) {
            const path = 'http://'+json.ip+':'+json.port+'/lists';
            const token = this.$store.getters.getJwtToken;
            axios.put(path, payload, {headers: {token: token}})
                .then(() => {
               
                    this.getTodolists();
                })
                .catch((error) => {
                    console.log(error);
                    this.getTodolists();
                });
            },
            deleteList(todolist_id) {
                const path = 'http://'+json.ip+':'+json.port+'/lists/' + todolist_id;
                const token = this.$store.getters.getJwtToken;
                axios.delete(path, {headers: {token: token}})
                    .then(() => {
                        this.getTodolists();
                 
                    })
                    .catch((error) => {
                        console.error(error);
                        this.getTodolists();
                    });
            },
            editList(payload) {
                const path ='http://'+json.ip+':'+json.port+'/lists/' + this.editListForm.id;
                const token = this.$store.getters.getJwtToken;
                axios.patch(path, payload, {headers: {token: token}})
                .then(() => {
                    this.getTodolists();
                })
                .catch((error) => {
                    // eslint-disable-next-line
                    console.log(error);
                    this.getTodolists();
                });
            },
            initFormAddList() {
                this.addListForm.name = '';
            },
            onSubmitAddList(evt) {
                evt.preventDefault();
                this.$refs.addListModal.hide();
                const payload = {
                    name: this.addListForm.name,
               
                };
                this.addList(payload);
                this.initFormAddList();
            },
            onResetAddList(evt) {
                evt.preventDefault();
                this.initFormAddList();
            },
            editListId(todolist_id) {
                this.editListForm.id = todolist_id;
            },
            initFormEditList() {
                this.editListForm.name = '';
            },
            onSubmitEditList(evt) {
                evt.preventDefault();
                this.$refs.editListModal.hide();
                const payload = {
                    name: this.editListForm.name,
                };
                this.editList(payload);
                this.initFormEditList();
            },
            onResetEditList(evt) {
                evt.preventDefault();
                this.initFormEditList();
            },
        },
        created() {
            this.getTodolists();
        },
    };
</script>
